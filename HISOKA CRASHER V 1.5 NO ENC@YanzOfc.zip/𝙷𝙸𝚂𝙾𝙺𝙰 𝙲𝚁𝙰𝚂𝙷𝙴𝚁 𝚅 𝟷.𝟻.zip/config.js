module.exports = {
  BOT_TOKEN: "7519397823:AAHZC-Hi2qEwrOnCzRg22sKJ1e2EahvbLMI",
  allowedDevelopers: ['7292158376']
};