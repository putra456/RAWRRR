module.exports = {
  BOT_TOKEN: "7811596106:AAHGCaLbK3o5MIAdU3AXHhF_UEPIKbbBrlg",
    allowedDevelopers: ['6493353976'], // ID
};

// FOLOW SALURAN VINNTHEXDC
// https://whatsapp.com/channel/0029VavOzFy8KMqqMvMnOW1k