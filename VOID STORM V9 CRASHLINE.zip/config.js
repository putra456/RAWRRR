module.exports = {
  BOT_TOKEN: "7818835440:AAESa7s7lNOuPblaXdMMSHCGvok8cO4RNrE", 
};